﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapBaker : MonoBehaviour {
    public Mesh m_CubeMesh;
}
